<template>
  <Center>
      <img src="../assets/404.gif" alt="" srcset="">
  </Center>
</template>

<script>
import Center from '../components/Center'
export default {

}
</script>

<style scoped>

</style>