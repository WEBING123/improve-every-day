<template>
  <Center>
      注册
  </Center>
</template>

<script>
import Center from '../components/Center'
export default {

}
</script>

<style scoped>

</style>