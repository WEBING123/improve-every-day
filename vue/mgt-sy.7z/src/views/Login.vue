<template>
  <Center>
      登录
  </Center>
</template>

<script>
import Center from '../components/Center'
export default {

}
</script>

<style scoped>

</style>